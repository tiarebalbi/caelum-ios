//
//  TBMapaViewController.m
//  Contatos
//
//  Created by ios4584 on 30/08/14.
//  Copyright (c) 2014 Tiarê Balbi. All rights reserved.
//

#import "TBMapaViewController.h"

#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@interface TBMapaViewController ()

@end

@implementation TBMapaViewController

- (id) init {
    if(self = [super init]) {
        self.title = @"Mapa";
        UIImage *icone = [UIImage imageNamed:@"Shape.png"];
        
        UITabBarItem *tabItem = [[UITabBarItem alloc] initWithTitle:@"Mapa" image:icone tag:0];
        self.tabBarItem = tabItem;
    }
    
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    
    // TabBar
    [[UITabBar appearance] setTintColor:UIColorFromRGB(0xFFFFFF)];
    [[UITabBar appearance] setBarTintColor:UIColorFromRGB(0x202024)];
    
    // Barra de Navegação Superior
    [[UINavigationBar appearance] setBarTintColor:UIColorFromRGB(0x0F1830)];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    
    // Mascara relogio
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName,nil]];
    
    MKUserTrackingBarButtonItem *botaoLocalizacao = [[MKUserTrackingBarButtonItem alloc] initWithMapView:self.mapa];
    self.navigationItem.leftBarButtonItem = botaoLocalizacao;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
